﻿Public Class Login


    Private Sub Login_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'EyeclinicDataset.Administrator' table. You can move, or remove it, as needed.
        Me.AdministratorTableAdapter.Fill(Me.EyeclinicDataset.Administrator)
        'TODO: This line of code loads data into the 'EyeclinicDataset.Staff' table. You can move, or remove it, as needed.
        Me.StaffTableAdapter.Fill(Me.EyeclinicDataset.Staff)
        'TODO: This line of code loads data into the 'EyeclinicDataset.TraineeStudent' table. You can move, or remove it, as needed.
        Me.TraineeStudentTableAdapter.Fill(Me.EyeclinicDataset.TraineeStudent)

    End Sub

    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles Button2.Click
        MainMenu.Show()
        Me.Close()
    End Sub

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        ' Dim gen As String 'New var to hold data from the radio button
        MainMenu.global_username = TextBox1.Text
       
            MainMenu.global_staffType = "Administrator"
            AdministratorTableAdapter.FillBy(EyeclinicDataset.Administrator, TextBox1.Text, TextBox2.Text)
            If EyeclinicDataset.Administrator.Rows.Count > 0 Then
                MessageBox.Show("Welcome: You will now be redirected to the system")
                MainMenu.global_staffid = StaffTableAdapter.returnStaffID(TextBox1.Text, TextBox2.Text)
            With MainMenu
                .ToolStripMenuItem7.Visible = True
                .ToolStripMenuItem3.Visible = True
                .Patient.Visible = True
                .ToolStripMenuItem16.Visible = True
                .ToolStripMenuItem8.Visible = True
                .Show()
                'MessageBox.Show(MainMenu.stateVal + "")
                .ToolStripMenuItem2.Text = "Logout"
            End With
                Me.Close()


            TraineeStudentTableAdapter.FillBy(EyeclinicDataset.TraineeStudent, TextBox1.Text, TextBox2.Text)
        ElseIf EyeclinicDataset.TraineeStudent.Rows.Count > 0 Then
            MainMenu.global_staffType = "Trainee Student"
            MessageBox.Show("Welcome: You will now be redirected to the system")
            MainMenu.global_studentNo = TraineeStudentTableAdapter.ReturnStudentNo(TextBox1.Text, TextBox2.Text)

            With MainMenu
                .ToolStripMenuItem6.Visible = False
                .Patient.Visible = True
                .ToolStripMenuItem8.Visible = True
                .Show()
                .ToolStripMenuItem2.Text = "Logout"
            End With
            Me.Close()
        Else
            MessageBox.Show("Invalid User Details")
            TextBox1.Clear()
            TextBox2.Clear()
        End If

    End Sub
End Class
﻿Public Class AddNewDiagnosis

    Private Sub AddNewDiagnosis_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        PatientTableAdapter1.Fill(EyeclinicDataset.Patient)
        ConsultationTableAdapter1.Fill(EyeclinicDataset.Consultation)
        DiagnosisTableAdapter1.Fill(EyeclinicDataset.Diagnosis)
    End Sub

    Private Sub ToolStripButton3_Click(sender As System.Object, e As System.EventArgs) Handles ToolStripButton3.Click
        DiagnosisTableAdapter1.AddNewDiagnosis(TextBox2.Text, TextBox3.Text, DateTimePicker1.Value, TextBox4.Text, ComboBox2.SelectedItem, TextBox1.Text)
        DiagnosisTableAdapter1.Update(EyeclinicDataset.Diagnosis)
        BSPatient.RemoveFilter()
        DiagnosisTableAdapter1.Fill(EyeclinicDataset.Diagnosis)
        PatientTableAdapter1.UpdateBalance(TextBox1.Text, TextBox2.Text)
        BSPatient.EndEdit()
        PatientTableAdapter1.Update(EyeclinicDataset.Patient)
        PatientTableAdapter1.Fill(EyeclinicDataset.Patient)
        MessageBox.Show("Patient Diagnosis successfully captured!!!!")

    End Sub

    Private Sub ToolStripButton4_Click(sender As System.Object, e As System.EventArgs) Handles ToolStripButton4.Click
        Me.Close()
    End Sub

    Private Sub UpdateBalance(patID As Integer, balance As Double)
        For i As Integer = 0 To BSPatient.Count - 1
            If EyeclinicDataset.Patient.Rows(i)(0) = patID Then
                EyeclinicDataset.Patient.Rows(i)("Balance") += balance
            End If
        Next
    End Sub
End Class
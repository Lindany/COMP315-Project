#include <iostream>
#include "C:\Users\cna\Desktop\SpellingBee\include\Player.h"
#include "C:\Users\cna\Desktop\SpellingBee\include\PlayGame.h"

using namespace std;

int main()
{
    PlayGame* g = new PlayGame();
    //g->printResults();
    //cout<<g->generateWord();
    g->checkWord();
    return 0;
}

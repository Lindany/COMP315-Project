#ifndef GAMES_H
#define GAMES_H


class Games
{
public:
    Games();
};

#endif // GAMES_H
#ifndef WELCOME_H
#define WELCOME_H


class Welcome
{
public:
    Welcome();
};

#endif // WELCOME_H
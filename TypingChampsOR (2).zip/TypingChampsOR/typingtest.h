#ifndef TYPINGTEST_H
#define TYPINGTEST_H


class TypingTest
{
public:
    TypingTest();
};

#endif // TYPINGTEST_H
#include "statistics.h"

Statistics::Statistics()
{

}

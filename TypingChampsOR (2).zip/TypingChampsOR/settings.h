#ifndef SETTINGS_H
#define SETTINGS_H


class Settings
{
public:
    Settings();
};

#endif // SETTINGS_H
#include "Game.h"
#include <QTimer>
#include <QTime>
#include <QGraphicsTextItem>
#include <QFont>
#include "Number.h"
#include <QMediaPlayer>
#include "images.h"
#include <QBrush>
#include <QImage>
#include <QDebug>
#include <life.h>
#include <chrono>
#include <QThread>
#include <QRunnable>
//#include <qgraphicsitem_cast>



QTimer * timer;

Game::Game(QWidget *parent){
    // create the scene
    titleText = new QGraphicsTextItem(QString("learn_maths"));
    playButton = new Button(QString("Play"));
    quitButton = new Button(QString("Quit"));
    restart = new Button(QString("Restart"));

    logo = new Logo();


    scene = new QGraphicsScene();
    scene->setSceneRect(0,0,800,600); //


    setBackgroundBrush(QBrush(QImage(":/images/bgImage.png")));

    // make the newly created scene the scene to visualize (since Game is a QGraphicsView Widget,
    // it can be used to visualize scenes)
    setScene(scene);
    setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    setFixedSize(800,600);

    player = new Player();
    player->setPos(400,500);
    player->setFlag(QGraphicsItem::ItemIsFocusable);
    player->setFocus();


    score = new Score();
    bestscore = new Bestscore();


    timer = new QTimer();
    QObject::connect(timer,SIGNAL(timeout()),this,SLOT(createNumber()));

    backsound = new QMediaPlayer();
    backsound->setMedia(QUrl("qrc:/sound/backgroundsound.mp3"));



    life1 = new Life();
    life2 = new Life();
    life3 = new Life();
    life4 = new Life();


    this->addlife(life1);
    this->addlife(life2);
    this->addlife(life3);
    this->addlife(life4);

    speed=2;
    show();


}
void Game::start(){
    this->setboolvar(false);

     qDebug()<<this->getSizeofVector();
    if (restart!=NULL){
        scene->removeItem(restart);
    }
    if(this->getSizeofVector()==0){
        //afte game over manu insert the life back to the vector
        this->addlife(life1);
        this->addlife(life2);
        this->addlife(life3);
        this->addlife(life4);
        //restore the default position of the player/tank
        player->setPos(400,500);
        if (gameoversound->state() == QMediaPlayer::PlayingState){
            gameoversound->stop();
        }
    }

    int x =700;
    for(int i=0; i<this->getSizeofVector(); i++){
        this->getlife(i)->setPos(x,0);
        scene->addItem(this->getlife(i));
        x+=25;
    }

    qDebug()<<scene;
    player->setFocus();

     setBackgroundBrush(QBrush(QImage(":/images/bgImage.png")));

  // scene->removeItem(titleText);
   scene->removeItem(titleText);
   scene->removeItem(playButton);
   scene->removeItem(quitButton);


    scene->addItem(player);
    scene->addItem(score);
    scene->addItem(logo);

    if(bestscore->getbestscore() < score->getScore()){
        bestscore->setbestscore(score->getScore());
    }
    score->setScore();
    scene->addItem(bestscore);


    timer->start(1000);
    backsound->play();
}
void Game::mainmenu(){

        QFont titleFont("comic sans",50);
        titleText->setFont(titleFont);
        int txPos = this->width()/2 - titleText->boundingRect().width()/2;
        int tyPos = 150;
        titleText->setPos(txPos,tyPos);
        scene->addItem(titleText);

        int bxPos = this->width()/2 - playButton->boundingRect().width()/2;
        int byPos = 275;
        playButton->setPos(bxPos,byPos);
        connect(playButton,SIGNAL(clicked()),this,SLOT(start()));
        scene->addItem(playButton);

        int qxPos = this->width()/2 - quitButton->boundingRect().width()/2;
        int qyPos = 350;
        quitButton->setPos(qxPos,qyPos);
        connect(quitButton,SIGNAL(clicked()),this,SLOT(close()));
        scene->addItem(quitButton);
}
void Game::playAgain(){

    int bxPos = this->width()/2 - restart->boundingRect().width()/2;
    int byPos = 275;
    restart->setPos(bxPos,byPos);
    connect(restart,SIGNAL(clicked()),this,SLOT(start()));
    scene->addItem(restart);
    scene->addItem(quitButton);
    speed=5;


}
void Game::gameOver(){
    //this->clearNumVector();
    this->setboolvar(true);

    backsound->stop();
    scene->removeItem(player);
    scene->removeItem(logo);
    gameoversound = new QMediaPlayer();
    gameoversound->setMedia(QUrl("qrc:/sound/gameoversound.wav"));
    gameoversound->play();
    gameoversound->setPosition(1);
    setBackgroundBrush(QBrush(QImage(":/images/gameover.png")));
    timer->stop(); 
    this->playAgain();
}

void Game::createNumber(){
    Number * number = new Number();
    int temp = score->getScore();
    if(temp>0 && temp%10==0){
            if(!scoreStore.contains(temp)){
               scoreStore.append(temp);
               speed+=5;
            }
    }
     number->setSpeed(speed);
    this->addNumToVector(number);
   scene->addItem(this->getNum());
    if (backsound->state() == QMediaPlayer::StoppedState){
       backsound->play();
   }

    qDebug()<<"number: "<<number->getnum()<<"is created and added to the scene: "<<scene;
}


void Game::addlife( QGraphicsPixmapItem * life){
    vector.push_back(life);

}
void Game::removelife(){
    if (vector.size()){
         vector.pop_back();
      }

}
int Game::getSizeofVector(){
    return vector.size();
}
QGraphicsPixmapItem * Game::getlife(int i){
    return vector.at(i);
}
QGraphicsPixmapItem * Game::getlast(){
    return vector.at(vector.size()-1);
}

QGraphicsPixmapItem* Game::getNum(){
    return vectorForNum.at(vectorForNum.size()-1);
}

void Game::addNumToVector(QGraphicsPixmapItem* number){
    vectorForNum.push_back(number);
}
void Game::removeNumFromVector(QGraphicsPixmapItem* number){
    int temp = vectorForNum.indexOf(number);
    //vectorForNum.at(temp)=NULL;
}
void Game::clearNumVector(){
    for(int i=0;i<vectorForNum.size();i++){
        qDebug()<<vectorForNum.at(i);
        vectorForNum.remove(i);
    }
}

bool Game::getboolvar(){
    return var;
}
void Game::setboolvar(bool tof){
    var=tof;
}

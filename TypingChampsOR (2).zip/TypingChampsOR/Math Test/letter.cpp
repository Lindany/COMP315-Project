#include "letter.h"
#include <QTimer>
#include <QGraphicsScene>
#include <QList>
#include <stdlib.h>
#include "Game2.h"
#include <QKeyEvent>

extern Game2 * game2;

Letter::Letter(QGraphicsItem *parent): QObject(), QGraphicsPixmapItem(parent){
    //set random x position
    int random_number = rand() % 700;
    setPos(random_number,0);
    number = 1+rand()%3;
    if (number==1){
        //qDebug()<<number->getnum();
        setpath(":/letters/a.png");
    }
    else if (number==2){
       // qDebug()<<number->getnum();
        setpath(":/letters/b.png");
    }
    else if (number==3){
       // qDebug()<<number->getnum();
        setpath(":/letters/c.png");
    }
    else {
        setpath(":/images/one.png");
    }


    // make/connect a timer to move()
    QTimer * timer = new QTimer(this);
    connect(timer,SIGNAL(timeout()),this,SLOT(move()));

    // start the timer
    timer->start(50);
}

void Letter::move(){

    setPos(x(),y()+5);


    if (pos().y() > 600){
        //decrease the health
        game2->health->decrease();

        scene()->removeItem(this);
        delete this;
    }
}
int Letter::getnum(){
    return number;
}
void Letter::setpath(QString path){
     setPixmap(QPixmap(path));
}
void Letter::keyPressEvent(QKeyEvent *event){
    if (event->key() == Qt::Key_A){
        game2->scene->removeItem(this);
    }
}

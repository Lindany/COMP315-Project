#ifndef LOGO_H
#define LOGO_H

#include <QGraphicsPixmapItem>
#include <QObject>
#include <QGraphicsItem>
#include <QMediaPlayer>

class Logo: public QObject,public QGraphicsPixmapItem{
    Q_OBJECT
public:
    Logo(QGraphicsItem * parent=0);
    QMediaPlayer * logosound;

};

#endif // LOGO_H

#include "Bullet.h"
#include <QTimer>
#include <QGraphicsScene>
#include <QList>
#include "number.h"
#include "game.h"
#include <typeinfo>

extern Game * game;//
Bullet::Bullet(QGraphicsItem *parent): QObject(), QGraphicsPixmapItem(parent){

    setPixmap(QPixmap(":/images/bullet.png"));


    QTimer * timerforB = new QTimer(this);
    connect(timerforB,SIGNAL(timeout()),this,SLOT(move()));
    timerforB->start(15);
}

void Bullet::move(){

    QList<QGraphicsItem *> colliding_items = collidingItems();


    for (int i = 0, n = colliding_items.size(); i < n; ++i){
        if (typeid(*(colliding_items[i])) == typeid(Number)){
            Number *item = dynamic_cast<Number*>(colliding_items[i]);
            if (item->getnum()%2==0){
                game->score->increase();
            }
            else{
                game->scene->removeItem(game->getlast());
                game->removelife();
                if(game->getSizeofVector()==0){
                    game->gameOver();
                    //game->clearNumVector();
                }
            }

            game->scene->removeItem(colliding_items[i]);
            game->scene->removeItem(this);

            delete colliding_items[i];
            delete this;
            // return (all code below refers to a non existint bullet)
            return;
        }
    }
    // if there was no collision with an Number, move the bullet forward
    setPos(x(),y()-10);
    // if the bullet is off the screen, destroy it
    if (pos().y() < 0){
        game->scene->removeItem(this);
        delete this;
    }
}


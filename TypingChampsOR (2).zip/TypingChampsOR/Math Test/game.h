#ifndef GAME_H
#define GAME_H

#include <QGraphicsView>
#include <QWidget>
#include <QGraphicsScene>
#include "Player.h"
#include "Score.h"
#include "life.h"
#include "button.h"
#include "bestscore.h"
#include "logo.h"
#include  <QVector>



class Game: public QGraphicsView{
     Q_OBJECT
public:
    Game(QWidget * parent=0);

    QGraphicsScene * scene;
    Player * player;
    Score * score;
    Bestscore * bestscore;


    QGraphicsTextItem* titleText;
    Button* playButton;
    Button* quitButton;
    Button* restart;

    QMediaPlayer *backsound;
    QMediaPlayer *gameoversound;

    //stages



    void gameOver();

    void addlife(QGraphicsPixmapItem *file);
    void removelife();
    int getSizeofVector();
    QGraphicsPixmapItem *getlife(int i);
    QGraphicsPixmapItem *getlast();

    Logo *logo;

    void addNumToVector(QGraphicsPixmapItem* number);
    void removeNumFromVector(QGraphicsPixmapItem* number);
    void clearNumVector();
    bool getboolvar();
    void setboolvar(bool tof);
    QGraphicsPixmapItem* getNum();
    Life *life1 ;
    Life *life2 ;
    Life *life3 ;
    Life *life4 ;
    void mainmenu();
    void playAgain();
private:
    QVector<QGraphicsPixmapItem*> vector; //to store the lifes of a player
    QVector<QGraphicsPixmapItem*> vector2; //to store special bullets
    QVector<QGraphicsPixmapItem*> vectorForNum;
    int ScoreChanged;
    int speed;
    QVector<int> scoreStore;
    bool var;
public slots:
       void start();
       void createNumber();
};

#endif // GAME_H

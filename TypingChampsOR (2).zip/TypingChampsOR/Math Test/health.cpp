#include "Health.h"
#include <QGraphicsScene>
#include "Game.h"


extern Game * game;

Health::Health(QGraphicsItem *parent): QGraphicsPixmapItem(parent){
    // initialize the score to 0
    health = 3;
//    for(int i=0;i<3;i++){
//        vector->push_back(new QGraphicsPixmapItem() );
//        vector->at(i).setPixmap(":/images/oneUp.png");
//        setPos(x()+550+50,y());
//        scene()->addItem(vector->at(i));
//    }
//    setPixmap(":/images/oneUp.png");
//    setPos(x()+550+50,y());
//    scene()->addItem(this);

//
}

void Health::decrease(){
    health--;
//    if (vector->size()>0){
//        vector->pop_front();
//    }

}

int Health::getHealth(){
    return health;
}

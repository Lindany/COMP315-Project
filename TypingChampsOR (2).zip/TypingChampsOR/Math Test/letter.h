#ifndef LETTER_H
#define LETTER_H

#include <QGraphicsPixmapItem>
#include <QObject>
#include <QGraphicsItem>
#include <QKeyEvent>
#include <vector>
#include <QList>

class Letter: public QObject,public QGraphicsPixmapItem{
    Q_OBJECT
public:
    Letter(QGraphicsItem * parent=0);
    void setpath(QString path);
    int getnum();
    void keyPressEvent(QKeyEvent * event);
public slots:
    void move();
private:
    int number;
    //QList eventsList;

};
#endif // LETTER_H

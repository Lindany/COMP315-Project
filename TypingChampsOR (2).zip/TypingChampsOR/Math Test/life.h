


#ifndef LIFE_H
#define LIFE_H

#include <QGraphicsPixmapItem>
#include <QObject>
#include <QGraphicsItem>
#include <QMediaPlayer>

class Life:public QObject, public QGraphicsPixmapItem{
    Q_OBJECT
public:
    Life(QGraphicsItem * parent=0);


private:
    QMediaPlayer * LifeRemoveSound;
};

#endif // LIFE_H

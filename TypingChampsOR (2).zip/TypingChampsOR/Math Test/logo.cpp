#include "logo.h"
#include <QGraphicsScene>

Logo::Logo(QGraphicsItem *parent): QGraphicsPixmapItem(parent){

    logosound = new QMediaPlayer();
    logosound->setMedia(QUrl("qrc:/sound/shoot.wav"));
    // set graphic
    setPixmap(QPixmap(":/images/evennumber.png"));
    setPos(215,0);
}

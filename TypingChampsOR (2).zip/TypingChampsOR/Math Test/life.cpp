#include "life.h"
#include <QGraphicsScene>

Life::Life(QGraphicsItem *parent): QGraphicsPixmapItem(parent){
    // set bullet sound
    LifeRemoveSound = new QMediaPlayer();
    LifeRemoveSound  = new QMediaPlayer();
    LifeRemoveSound ->setMedia(QUrl("qrc:/sound/shoot.wav"));
    // set graphic
    setPixmap(QPixmap(":/images/oneUp.png"));
}


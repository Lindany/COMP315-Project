


#ifndef BESTSCORE_H
#define BESTSCORE_H

#include <QGraphicsTextItem>

class Bestscore: public QGraphicsTextItem{
public:
    Bestscore(QGraphicsItem * parent=0);
    void setbestscore(int score);
    int getbestscore();
private:
    int bestscore;
};

#endif // BESTSCORE_H

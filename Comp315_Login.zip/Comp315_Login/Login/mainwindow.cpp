#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMessageBox>
#include <QPixmap>
#include <QFile.h>
#include <QTextstream.h>
#include <QDebug.h>
#include <iostream>

using namespace std;

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    QPixmap picture("C:/Users/Nothando/Desktop/Modules/COMP_315_QT_Codes/Images/loginIcon.jpg");
    ui->PictureLabel->setPixmap(picture.scaled(170,170,Qt::KeepAspectRatio));

    QPalette* palette = new QPalette();
    palette->setBrush(QPalette::Background,*(new QBrush(*(new QPixmap("C:/Users/Nothando/Desktop/Modules/COMP_315_QT_Codes/Images/backgroundImage2.jpg")))));
    setPalette(*palette);
}

MainWindow::~MainWindow()
{
    delete ui;
}
bool MainWindow::checkCredentials()
{
    QString username = ui->lineEdit->text();
    QString password = ui->lineEdit_2->text();
    QFile file("C:/Users/Nothando/Desktop/Modules/COMP_315_QT_Codes/userDatabase.txt");
    QStringList list;

    if (file.open(QIODevice::ReadOnly | QIODevice::Text))
    {
       QTextStream in(&file);
       while (!in.atEnd())
       {
           QString content = in.readLine();
           list = content.split(" ");
           if(list[0] == username && list[4] == password)
           {
               return true;
           }

       }
       return false;
       file.close();
    }
}

void MainWindow::login()
{
    if(checkCredentials()==true)
    {
        QMessageBox::information(this,"Login","User credentials are correct!!");
    }
    else
    {
        QMessageBox::warning(this,"Login","Incorrect username or Password");
    }

}


void MainWindow::on_signUp_clicked()
{
    QString name = ui->lineEdit_3->text();
    QString surname = ui->lineEdit_4->text();
    QString gender = ui->comboBox->currentText();
    QString DoB = ui->dateEdit->text();
    QString password = ui->lineEdit_5->text();
    QString confirmedPassword = ui->lineEdit_6->text();

    if(password == confirmedPassword)
    {
        QMessageBox::information(this,"Sign Up","Congratulations! , You have a new account");
    }
    else
    {
        QMessageBox::warning(this,"Sign Up","Passwords does not match");
    }

    QFile file("C:/Users/Nothando/Desktop/Modules/COMP_315_QT_Codes/userDatabase.txt");
    file.open(QIODevice::Append);

    if(!file.isOpen())
    {
        qDebug("Error, unable to open the file");
    }

    QTextStream outStream(&file);
    outStream <<"\n";
    outStream <<name<<" ";
    outStream << surname << " ";
    outStream << gender << " ";
    outStream << DoB << " ";
    outStream << confirmedPassword;

    file.close();
}

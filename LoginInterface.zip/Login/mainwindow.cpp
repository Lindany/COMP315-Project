#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMessageBox>
#include <QPixmap>
#include <QFile.h>
#include <QTextstream.h>
#include <QDebug>
#include <iostream>
#include <map>
using namespace std;

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    QPixmap picture("C:/Users/Nothando/Desktop/Modules/COMP_315_QT_Codes/Images/loginIcon.jpg");
    ui->PictureLabel->setPixmap(picture.scaled(170,170,Qt::KeepAspectRatio));

    QPalette* palette = new QPalette();
    palette->setBrush(QPalette::Background,*(new QBrush(*(new QPixmap("C:/Users/Nothando/Desktop/Modules/COMP_315_QT_Codes/Images/backgroundImage2.jpg")))));
    setPalette(*palette);
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_pushButton_clicked()
{
    QStringList list;
    QString username = ui->lineEdit->text();
    QString password = ui->lineEdit_2->text();
    QFile file("C:/Users/Nothando/Desktop/Modules/COMP_315_QT_Codes/userDatabase.txt");
    if (file.open(QIODevice::ReadOnly | QIODevice::Text))
    {
       QTextStream in(&file);
       while (!in.atEnd())
       {
           QString content = in.readLine();
           QString a[3] = {'\t', '\n'," "};

           for(int i = 0; i <3; i++){
               if(content.contains(a[i])){
                   list = content.split(a[i]);
               }
           }

       }
       file.close();
    }
    //***********************************************************************************
    std::pair<char , char> pairs;
    map<std::string , std::string > myMap;
    QString a;
    QString b;
    for(int i = 0; i < list.size() ; i++){
        list[1] = a;
        list[3] = b;
        pairs.first = a;
        pairs.second = b;
        myMap.insert(pairs);
    }
    map<std::string , std::string >::iterator it = myMap.begin();
    for(it = myMap.begin() ;it != myMap.end() ; it++ ){
        qDebug()<<(*it)->first;
    }

    //***********************************************************************************
    if(list.contains(username) && list.contains(password))
    {
        qDebug()<<"User credentials are correct!!";
          QMessageBox::information(this,"Login","User credentials are correct!!");
    }

    else
        {
          QMessageBox::warning(this,"Login","Incorrect username or Password");
          qDebug()<<"User credentials are not correct!!";
        }

}
